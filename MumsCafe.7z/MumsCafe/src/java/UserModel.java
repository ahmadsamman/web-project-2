import java.util.List;
 
public class UserModel {
    private String name;
    
    
    private String Email;
    private String PhoneNo;
    
    //username and password
    private String username;
    private String password;
    
    public UserModel(String name, String mail, String PhnNo, String username, String password) {
        this.name = name;
        this.Email= mail;
        this.PhoneNo=PhnNo;
        
        this.username = username;
        this.password = password;
        
        
    }
    public String getName() {
        return name;
    }
    public String getPhoneNo(){
        return PhoneNo;
    }
    public String getEmail()
    {
        return Email;
    }
     public String getUsername() {
        return username;
    }
    
     public String getPassword() {
        return password;
    }

    
}
