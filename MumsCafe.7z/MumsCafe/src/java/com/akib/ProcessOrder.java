/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
akibul hasan
a17cs4015
 */
package com.akib;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author akib
 */
@WebServlet(name = "ProcessOrder", urlPatterns = {"/process"})
public class ProcessOrder extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        
        String  set1 = request.getParameter("Set1Checkbox");
        String  set2 = request.getParameter("Set2Checkbox");
        String  set3 = request.getParameter("Set3Checkbox");
        
        
        String  set1drink = request.getParameter("set1DrinkOption");
        String  set2drink = request.getParameter("set2DrinkOption");
        String  set3drink = request.getParameter("set3DrinkOption");
        
         String  set1quantity = request.getParameter("set1OrderQuantity");
        String  set2quantity = request.getParameter("set2OrderQuantity");
        String  set3quantity = request.getParameter("set3OrderQuantity");
        
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProcessOrder</title>");  
            out.println(" <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\"> ");
           
            out.println("</head>");
            out.println("<body>");
            
            
             out.println("<div class=\"container\">");
            
            out.println("<table class=\"table table-bordered table-dark\">");
            
            out.println("<thead><tr>");
            
            out.println("<th>Food</th>");
             out.println("<th>Drink</th>");
              out.println("<th>Quantity</th>");
               out.println("<th>Cost(RM)</th>");
            
            out.println("</tr></thead>");
            
            
            out.println("<tbody>");
            
            out.println("<tr>");
            
            
            out.println("<td>" + set1 + "</td>");
             out.println("<td>" + set1drink + "</td>");
             out.println("<td>" + set1quantity + "</td>");
            
            out.println("</tr>");
            
            
             out.println("<tr>");
            
            
            out.println("<td>" + set2 + "</td>");
             out.println("<td>" + set2drink + "</td>");
              out.println("<td>" + set2quantity + "</td>");
            
            out.println("</tr>");
            
            
            
             out.println("<tr>");
            
            
            out.println("<td>" + set3 + "</td>");
             out.println("<td>" + set3drink + "</td>");
              out.println("<td>" + set3quantity + "</td>");
            
            out.println("</tr>");
                    
            
            
            out.println("</tbody>");
            
            out.println("</table>");
            
            out.println("</div>");
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
